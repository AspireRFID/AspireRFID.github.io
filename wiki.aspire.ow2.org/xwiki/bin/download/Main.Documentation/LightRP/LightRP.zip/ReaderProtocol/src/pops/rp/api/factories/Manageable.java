package pops.rp.api.factories;

import pops.rp.api.DataSelector;
import pops.rp.api.NotificationChannel;
import pops.rp.api.RPException;
import pops.rp.api.Source;
import pops.rp.api.TagField;
import pops.rp.api.TagSelector;
import pops.rp.api.Trigger;
import pops.rp.api.enumerations.TriggerType;

/**
 * This interface specifies a Manageable Reader. For creation and maximum 
 * number support for each model component : Source, NotificationChannel...etc.
 * 
 * @author rdagher
 *
 */
public interface Manageable {
	
	/*
	 * Object Source.
	 */
	public Source Source_create(String name) throws RPException;
	
	public int Source_getMaxNumberSupported() throws RPException;
	
	/*
	 * Object Trigger.
	 */
	public Trigger Trigger_create (String name, TriggerType type, String value)throws RPException;
	
	public int Trigger_getMaxNumberSupported() throws RPException;
	
	/*
	 * Object TagSelector.
	 */
	public TagSelector TagSelector_create(String name,
										  TagField field,
										  String value /* hex */,
										  String mask /* hex */,
										  boolean inclusiveFlag)throws RPException;
	
	public int TagSelector_getMaxNumberSupported() throws RPException;
	
	/*
	 * Object NotificationChannel.
	 */
	public NotificationChannel NotificationChannel_create (String name, String address)throws RPException;
	
	public int NotificationChannel_getMaxNumberSupported() throws RPException;
	
	/*
	 * Object DataSelector.
	 */
	public DataSelector DataSelector_create (String name)throws RPException;
	
	public int DataSelector_getMaxNumberSupported() throws RPException;
	
	
	/*
	 * Object TagField.
	 */
	public TagField TagField_create (String name)throws RPException;
	
	public int TagField_getMaxNumberSupported() throws RPException;	
	
}
