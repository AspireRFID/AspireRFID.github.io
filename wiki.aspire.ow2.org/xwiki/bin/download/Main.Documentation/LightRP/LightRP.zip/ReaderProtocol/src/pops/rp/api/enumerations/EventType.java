package pops.rp.api.enumerations;

public interface EventType {
	public final static String EV_GLIMPSED = "evGlimpsed";
	public final static String EV_LOST = "evLost" ;
	public final static String EV_NEW = "evNew";
	public final static String EV_OBSERVED = "evObserved";
	public final static String EV_PURGED = "evPurged";
	public final static String EV_UNKNOWN = "evUnknown";
	
	public String[] getSupportedTypes();
}
