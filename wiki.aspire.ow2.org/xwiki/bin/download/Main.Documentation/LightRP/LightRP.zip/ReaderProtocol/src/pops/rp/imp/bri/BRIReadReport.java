package pops.rp.imp.bri;

import java.util.ArrayList;
import java.util.List;

import pops.rp.api.readreport.ReadReport;

/**
 * A Bri Read Report.
 * Two singleton are decared :
 * <ul>
 * 	<li> EMPTY_BRI_READ_REPORT : for empty reports</li>
 * 	<li> REUSABLE_REPORT : singleton for single shot mode </li>
 * </ul>
 * 
 * @author rdagher
 *
 */
public class BRIReadReport implements ReadReport {

	protected final static BRIReadReport EMPTY_BRI_READ_REPORT = new BRIReadReport();
	
	protected static BRIReadReport REUSABLE_REPORT = new BRIReadReport();
	
	/**
	 * List of tag Ids associated with the unique default source.
	 */
	private List tagIds;	
	
	
	/**
	 * Constructor
	 */
	protected BRIReadReport() {
		tagIds = new ArrayList() ;
	}

	protected synchronized void addTag(String hexId) {
		tagIds.add(hexId);
	}
	
	/**
	 * Returns a copy of the report. This operation pops the contents of the 
	 * report for reusing the same object..
	 */
	public synchronized String[] getTagIds(String sourceName) {
		String [] tags;
		
		tags = (String[]) tagIds.toArray(new String[tagIds.size()]);
		tagIds.clear();
		
		return tags;
	}

}
