package pops.rp.api.enumerations;

public interface TriggerType {
	public final static String CONTINUOUS = "continuous";
	public final static String TIMER = "timer";
	public final static String IO_EDGE = "ioEdge";
	public final static String IO_VALUE = "ioValue";
	
	public String[] getSupportedTypes();	
}
