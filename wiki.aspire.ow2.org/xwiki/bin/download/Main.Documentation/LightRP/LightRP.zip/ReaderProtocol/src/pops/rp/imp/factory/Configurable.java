package pops.rp.imp.factory;

import pops.rp.api.RPException;

/**
 * Defines the configuration contract of a reader device.
 * 
 * @author rdagher
 *
 */
public interface Configurable {
	
	/**
	 * Power index minimum value.
	 */
	public final static int POWER_IDX_MIN_VALUE = 1 ;
	
	/**
	 * Power index maximum value.
	 */
	public final static int POWER_IDX_MAX_VALUE = 5 ;
	
	/**
	 * Session parameter minimum value.
	 */
	public final static int SESSION_MIN_VALUE = 0 ;
	
	/**
	 * Session parameter maximum value.
	 */
	public final static int SESSION_MAX_VALUE = 3 ;
	
	/**
	 * InitialQ parameter minimum value.
	 */
	public final static int INITIALQ_MIN_VALUE = 0 ;
	
	/**
	 * InitialQ parameter maximum value.
	 */
	public final static int INITIALQ_MAX_VALUE = 15 ;
	
	/**
	 * Set the Reader's RF power.
	 * @param powerIndex from 1 to 5.
	 * The index is used for look up in the power mapping (an array of 5 elements) containing the values to set on the reader.
	 * The values are reader dependent : 
	 * <ul>
	 *  <li>{@link ReaderFactory#BRI_POWER_MAPPING}</li>
	 * 	<li>{@link ReaderFactory#CAEN_POWER_MAPPING}</li>
	 * </ul>
	 */
	public void setPower(int powerIndex, int[] powerMapping) throws RPException;
	
	/**
	 * Set the session.
	 * @param session 0 or 1.
	 */
	public void setSession(int session) throws RPException;
	
	/**
	 * Initial Q setter.
	 * @param initialQ used to lead the tree of reading of tags. 0 to 15.
	 */
	public void setInitialQ(int initialQ) throws RPException;

}
