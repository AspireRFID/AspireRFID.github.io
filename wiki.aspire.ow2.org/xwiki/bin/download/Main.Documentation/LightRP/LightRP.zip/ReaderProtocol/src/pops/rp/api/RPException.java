package pops.rp.api;

/**
 * This exception is thrown if something goes wrong in a RP API operation.
 * 
 * @author rdagher
 */
public class RPException extends Exception {

	public final static RPException NOT_SUPPORTED_OPERATION = new RPException("Icom/Decathlon : unsupported operation");
	/**
	 * Constructor
	 */
	public RPException() {
		super();
	}

	/**
	 * Constructor
	 * @param message
	 * @param cause
	 */
	public RPException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructor
	 * @param message
	 */
	public RPException(String message) {
		super(message);
	}

	/**
	 * Constructor
	 * @param cause
	 */
	public RPException(Throwable cause) {
		super(cause);
	}
}