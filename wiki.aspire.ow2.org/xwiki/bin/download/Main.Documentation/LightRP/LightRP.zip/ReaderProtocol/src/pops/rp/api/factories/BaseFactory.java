package pops.rp.api.factories;

import pops.rp.api.ReaderDevice;

public abstract class BaseFactory {
	protected static Manageable currentReader = null;
	
	public static void setCurrentReaderDevice(ReaderDevice readerDevice) {
		if (readerDevice instanceof Manageable)
			currentReader = (Manageable)readerDevice;
		else
			throw new IllegalArgumentException("Reader Device does not implement Manageable interface : " + readerDevice.getClass());
	}
}
