package pops.rp.imp.bri;

import pops.rp.api.DataSelector;
import pops.rp.api.RPException;
import pops.rp.api.enumerations.EventType;
import pops.rp.api.enumerations.FieldName;
import pops.rp.api.enumerations.PredefinedTagFieldName;

public class BRIDataSelector implements DataSelector, EventType, FieldName {
	/**
	 * Data Selector object name.
	 */
	private String name;
	
	/**
	 * @see FieldName
	 */
	private String[] fieldNames;
	
	/**
	 * @see EventType
	 */
	private String[] eventFilters;
	
	/**
	 * Tag fields : example ID, Kill password, etc.
	 * @see PredefinedTagFieldName.
	 */
	private String[] tagFieldNames;	

	/**
	 * Constructor
	 * @param name
	 * @param fieldNames
	 * @param eventFilters
	 * @param tagFieldNames
	 */
	protected BRIDataSelector(String name, String[] fieldNames,
			String[] eventFilters, String[] tagFieldNames) {
		this.name = name;
		this.fieldNames = fieldNames;
		this.eventFilters = eventFilters;
		this.tagFieldNames = tagFieldNames;
	}
	
	/**
	 * 
	 * Default constructor Constructor
	 */
	protected BRIDataSelector(String name) {
		this.name = name;
		this.fieldNames = FieldName.MANDATORY_FIELDS;
		this.eventFilters = new String[0]; 	// empty
		this.tagFieldNames = new String[1];
		this.tagFieldNames[0] = PredefinedTagFieldName.tagID;
	}

	public void addEventFilters(String[] events) throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;
	}

	public void addFieldNames(String[] fields) throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public void addTagFieldNames(String[] fieldNames) throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public String[] getAllEventFilters() throws RPException {
		return this.eventFilters;
	}

	public String[] getAllFieldNames() throws RPException {
		return this.fieldNames;
	}

	public String[] getAllTagFieldNames() throws RPException {
		return this.tagFieldNames;
	}

	public String getName() throws RPException {
		return this.name;
	}

	public void removeAllEventFilters() throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public void removeAllFieldNames() throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public void removeAllTagFieldNames() throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public void removeEventFilters(String[] events) throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public void removeFieldNames(String[] fields) throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}

	public void removeTagFieldNames(String[] fieldNames) throws RPException {
		throw RPException.NOT_SUPPORTED_OPERATION;

	}
	
	/////////////////////////////////
	// EventType Implementation    //
	/////////////////////////////////
	/**
	 * No events support.
	 */
	public String[] getSupportedTypes() {
		return null;
	}

	/////////////////////////////////
	// FieldName Implementation    //
	/////////////////////////////////
	/**
	 * Only mandatory fields are supported.
	 */
	public String[] getSupportedNames() {
		return FieldName.MANDATORY_FIELDS;
	}

}
