package pops.rp.api;


public interface Trigger {
	
	public String getName() throws RPException;

	public String getType() throws RPException;

	public String getValue() throws RPException;

	public void fire() throws RPException;

}