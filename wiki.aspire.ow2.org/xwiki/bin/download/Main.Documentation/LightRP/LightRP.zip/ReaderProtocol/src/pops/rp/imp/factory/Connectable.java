package pops.rp.imp.factory;

import pops.rp.api.RPException;

/**
 * Defines the connection contract of a reader device.
 * 
 * @author rdagher
 *
 */
public interface Connectable  {
	/**
	 * Gets the default connection address for a Reader.
	 * @return the default address.
	 */
	public String getDefaultAddress();
	
	/**
	 * Connect to a reader at a given address.
	 * @param address connection address.
	 * @throws RPException in case of connection error.
	 */
	public void connect(String address) throws RPException;
	
	/**
	 * Disconnect from a reader.
	 * @throws RPException in case of disconnection error.
	 */
	public void discconnect() throws RPException;
}
