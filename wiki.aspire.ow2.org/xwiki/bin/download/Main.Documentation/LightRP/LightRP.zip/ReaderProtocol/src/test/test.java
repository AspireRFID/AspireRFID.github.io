package test;

import pops.rp.api.DataSelector;
import pops.rp.api.ReaderDevice;
import pops.rp.api.Source;
import pops.rp.api.factories.BaseFactory;
import pops.rp.api.factories.DataSelectorFactory;
import pops.rp.api.factories.NotificationChannelFactory;
import pops.rp.api.factories.SourceFactory;
import pops.rp.api.factories.TagFieldFactory;
import pops.rp.api.factories.TagSelectorFactory;
import pops.rp.api.factories.TriggerFactory;
import pops.rp.api.readreport.ReadReport;
import pops.rp.imp.factory.ReaderFactory;


public class test {

	public static void main (String[] args) throws Exception {
			
		if ("CAEN".equalsIgnoreCase(args[0]))
			Test_rawReadIDs_CAEN();
		else if ("INTERMEC".equalsIgnoreCase(args[0]))
			Test_rawReadIDs_Intermec();
		else 
			throw new IllegalArgumentException("Pass the reader type as argument : CAEN or INTERMEC");
		
	}
	
	public static void Test_Support(ReaderDevice reader) throws Exception {
		
		System.out.println("Reader Information :");
		System.out.println("\tName: " + reader.getName());
		
		BaseFactory.setCurrentReaderDevice(reader);
		System.out.println("\tMaxDataSelectors: " + DataSelectorFactory.getMaxNumberSupported());
		System.out.println("\tMaxSource: " + SourceFactory.getMaxNumberSupported());
		System.out.println("\tMaxNotifChannels: " + NotificationChannelFactory.getMaxNumberSupported());
		System.out.println("\tMaxTriggers: " + TriggerFactory.getMaxNumberSupported());
		System.out.println("\tMaxTagField " + TagFieldFactory.getMaxNumberSupported());
		System.out.println("\tMaxTagSelectors " + TagSelectorFactory.getMaxNumberSupported());
	}
	
	/**
	 * This test case validates the rawReadIDs method.
	 * The latter displays all tags in fields without applying any
	 * of the programmed tag selectors.
	 * 
	 * @throws Exception
	 */
	public static void Test_rawReadIDs_Intermec() throws Exception {
		ReaderDevice myReader;
				
		// Reader singleton
		myReader = ReaderFactory.getReader(ReaderFactory.BRI_READER, "BRIReaderDevice");
		
		// Test It
		Test_rawReadIDs(myReader);
	}
	
	/**
	 * This test case validates the rawReadIDs method.
	 * The latter displays all tags in fields without applying any
	 * of the programmed tag selectors.
	 * 
	 * @throws Exception
	 */
	public static void Test_rawReadIDs_CAEN() throws Exception {
		ReaderDevice myReader;
				
		// Reader singleton
		myReader = ReaderFactory.getReader(ReaderFactory.CAEN_READER, "CAENReaderDevice");
		
		// Test It
		Test_rawReadIDs(myReader);
	}
	
	/**
	 * This test case validates the rawReadIDs method.
	 * The latter displays all tags in fields without applying any
	 * of the programmed tag selectors.
	 * 
	 * @throws Exception
	 */
	public static void Test_rawReadIDs(ReaderDevice myReader) throws Exception {
		Source mySource;
		DataSelector myDataSelector;
				
		// Establish Connections
		ReaderFactory.connectReader(myReader);
		
		// Dump reader Info
		Test_Support(myReader);
		
		// Reader's Data Selector : default singleton for selecting IDs
		// This is is the default data selector that supports at least the tag ID field
		myDataSelector = myReader.getCurrentDataSelector(); // get Default Data Selector and update it
		
		// TODO :  validate reader support for EPCID, which is mandatory
		//myDataSelector.getAllTagFieldNames()
		
		// Reader's source : Singleton
		mySource = myReader.getCurrentSource();
		
		// Perform 10 read cycles
		for( int i = 0; i < 10 ; i++) {
			System.out.println("Read Cycle " + i + " at " + myReader.getTimeTicks() + " ticks");
			
			// Inventory
			ReadReport myReadReport = mySource.rawReadIDs(myDataSelector);
			
			if (myReadReport == null) {
				System.err.println("Error : mySource.rawReadIDs returned a null report ");
			}
			else {
				// Display read Tags
				String[] tagIds = myReadReport.getTagIds(mySource.getName());
				if (tagIds == null) {
					System.err.println("Error : myReadReport.getTagIds returned null ");
				}
				else if (tagIds.length == 0) {
					System.out.println("\t NO TAGS");
				}
				else {
					for(int j = 0 ; j < tagIds.length; j++)
						System.out.println("\tObserved : 0x" + tagIds[j]);
				}
			}
		}
		
		// graceful disconnect : equivalent to ReaderFactory.disconnectReader(myReader);
		myReader.goodbye();
		
		System.out.println("Done");
	}
	
}
