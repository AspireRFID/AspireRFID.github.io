package pops.rp.api.factories;

import pops.rp.api.DataSelector;
import pops.rp.api.RPException;

public class DataSelectorFactory extends BaseFactory{
	
	public static DataSelector create(String name) throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.DataSelector_create(name);
	}
	
	public static int getMaxNumberSupported() throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");		
		
		return currentReader.DataSelector_getMaxNumberSupported();
	}
}
