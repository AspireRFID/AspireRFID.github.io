package pops.rp.api.factories;

import pops.rp.api.NotificationChannel;
import pops.rp.api.RPException;

public class NotificationChannelFactory extends BaseFactory{

	public static NotificationChannel create(String name, String address) throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.NotificationChannel_create(name, address);
	}
	
	public static int getMaxNumberSupported() throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");	
		
		return currentReader.NotificationChannel_getMaxNumberSupported();
	}

}