package pops.rp.api.enumerations;

public interface FieldName {
	
	public final static String ALL                  = "all";
	public final static String ALL_EVENT            = "allEvent";
	public final static String ALL_NOTIFY           = "allNotify";
	public final static String ALL_READER           = "allReader";
	public final static String ALL_SOURCE           = "allSource";
	public final static String ALL_SUPPORTED        = "allSupported";
	public final static String ALL_TAG              = "allTag";
	public final static String EVENT_TIME_TICK      = "eventTimeTick";
	public final static String EVENT_TIME_UTC       = "eventTimeUTC";
	public final static String EVENT_TRIGGERS       = "eventTriggers";
	public final static String EVENT_TYPE           = "eventType";
	public final static String NOTIFY_CHANNEL_NAME  = "notifyChannelName";
	public final static String NOTIFY_TRIGGER_NAME  = "notifyTriggerName";
	public final static String READER_EPC           = "readerEPC";
	public final static String READER_HANDLE        = "readerHandle";
	public final static String READER_NAME          = "readerName";
	public final static String READER_NOW_TICK      = "readerNowTick";
	public final static String READER_NOW_UTC       = "readerNowUTC";
	public final static String READER_ROLE          = "readerRole";
	public final static String SOURCE_FREQUENCY     = "sourceFrequency";
	public final static String SOURCE_NAME          = "sourceName";
	public final static String SOURCE_PROTOCOL      = "sourceProtocol";
	public final static String TAGID                = "tagID";
	public final static String TAGID_AS_PURE_URI    = "tagIDasPureURI";
	public final static String TAGID_AS_TAG_URI     = "tagIDasTagURI";
	public final static String TAG_TYPE             = "tagType";
	
	public final String[] MANDATORY_FIELDS = {READER_EPC, READER_NAME, READER_ROLE, TAGID, ALL_SUPPORTED};
	
	public String[] getSupportedNames();
}
