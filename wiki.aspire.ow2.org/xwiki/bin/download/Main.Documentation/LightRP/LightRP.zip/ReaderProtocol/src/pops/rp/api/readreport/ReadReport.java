package pops.rp.api.readreport;



/**
 * This class defines a read report.
 * 
 * @author rdagher
 */
public interface ReadReport {
	
	/**
	 * Pops the tag Ids that for the tags in the field.
	 * 
	 * @param sourceName the source name.
	 * @return A list of ids (binary hex String) of observed tags.
	 */
	public String[] getTagIds(String sourceName);
}
