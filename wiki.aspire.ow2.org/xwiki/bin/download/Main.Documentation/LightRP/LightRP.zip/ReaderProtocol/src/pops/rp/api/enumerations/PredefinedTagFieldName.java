package pops.rp.api.enumerations;

public final class PredefinedTagFieldName {
	public final static String tagID = "tagID";
	public final static String accessPassword = "accessPassword";
	public final static String killPassword = "killPassword";
}
