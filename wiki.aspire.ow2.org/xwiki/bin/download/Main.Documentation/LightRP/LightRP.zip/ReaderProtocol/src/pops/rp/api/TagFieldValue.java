package pops.rp.api;



public interface TagFieldValue {

	/**
	 * 
	 * @return
	 * @throws RPException
	 */
	public String getTagFieldName() throws RPException;

	/**
	 * 
	 * @param tagFieldName
	 * @throws RPException
	 */
	public void setTagFieldName(String tagFieldName) throws RPException;

	/**
	 * Returns the data field’s corresponding data value.
	 * @return data value.
	 */
	public String getValue() throws RPException;

	/**
	 * Sets the data field’s corresponding data value.
	 * param data value.
	 */
	public void setValue(final String value) throws RPException;

}