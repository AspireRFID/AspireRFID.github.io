package pops.rp.api.factories;

import pops.rp.api.RPException;
import pops.rp.api.TagField;

public class TagFieldFactory extends BaseFactory{

	public static TagField create(String name) throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.TagField_create(name);
	}
	
	public static int getMaxNumberSupported() throws RPException {		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.TagField_getMaxNumberSupported();
	}

}