package pops.rp.api;


public interface TagField {

	public String getName() throws RPException;
	
	public String getTagFieldName() throws RPException;

	public void setTagFieldName(String tagFieldName) throws RPException;

	public int getMemoryBank() throws RPException;

	public void setMemoryBank(int memoryBank) throws RPException;

	public int getOffset() throws RPException;

	public void setOffset(int offset) throws RPException;

	public int getLength() throws RPException;

	public void setLength(int length) throws RPException;
}