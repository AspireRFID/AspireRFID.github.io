package pops.rp.api.factories;

import pops.rp.api.RPException;
import pops.rp.api.Source;

public class SourceFactory extends BaseFactory{

	public static Source create(String name) throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.Source_create(name);
	}
	
	public static int getMaxNumberSupported() throws RPException {		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.Source_getMaxNumberSupported();
	}
}