package pops.rp.imp.caen;

import pops.rp.api.RPException;
import pops.rp.api.ReadPoint;

public class CAENReadpoint implements ReadPoint {

	public final static CAENReadpoint ANT1 = new CAENReadpoint("1");	
	
	private String name;
			
	/**
	 * Constructor
	 * @param name
	 */
	public CAENReadpoint(String name) {
		this.name = name;
	}

	public String getName() throws RPException {
		return this.name;
	}

	/**
	 * The string representation of an antenna is its number.
	 */
	public String toString() {
		return this.name;
	}
	
	

}
