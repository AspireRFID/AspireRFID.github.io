
package pops.rp.api;


public interface TagSelector {
	
	public String getName() throws RPException;

	public TagField getTagField() throws RPException;

	public String getValue() throws RPException;

	public String getMask() throws RPException;

	public boolean getInclusiveFlag() throws RPException;
}