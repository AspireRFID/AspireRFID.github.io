package pops.rp.api;


/**
 * 
 * @author rdagher
 *
 */
public interface ReadPoint {

	/**
	 * Returns the name of the ReadPoint object.
	 * @return The name of the readpoint
	 */
	public String getName() throws RPException;

}