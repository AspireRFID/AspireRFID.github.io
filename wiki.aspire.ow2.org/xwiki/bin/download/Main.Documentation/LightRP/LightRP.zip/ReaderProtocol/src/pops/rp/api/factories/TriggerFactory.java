
package pops.rp.api.factories;

import pops.rp.api.RPException;
import pops.rp.api.Trigger;
import pops.rp.api.enumerations.TriggerType;

public class TriggerFactory extends BaseFactory{

	public static Trigger create(String name, TriggerType type, String value) throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.Trigger_create(name, type, value);
	}
	
	public static int getMaxNumberSupported() throws RPException {		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.Trigger_getMaxNumberSupported();
	}

}