package pops.rp.imp.bri;

import pops.rp.api.RPException;
import pops.rp.api.ReadPoint;

public class BRIReadpoint implements ReadPoint {

	public final static BRIReadpoint ANT1 = new BRIReadpoint("1");
	
	private String name;
			
	/**
	 * Constructor
	 * @param name
	 */
	public BRIReadpoint(String name) {
		this.name = name;
	}

	public String getName() throws RPException {
		return this.name;
	}

	/**
	 * The string representation of an antenna is its number.
	 */
	public String toString() {
		return this.name;
	}
	
	

}
