package pops.rp.api.factories;

import pops.rp.api.RPException;
import pops.rp.api.TagField;
import pops.rp.api.TagSelector;

public class TagSelectorFactory extends BaseFactory {

	public static TagSelector create(String name, TagField field,String value, String mask, boolean inclusiveFlag) throws RPException {
		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.TagSelector_create(name, field, value, mask, inclusiveFlag);
	}
	
	public static int getMaxNumberSupported() throws RPException {		
		if (currentReader == null)
			throw new RPException("No open Connection to any reader device");
		
		return currentReader.TagSelector_getMaxNumberSupported();
	}

}