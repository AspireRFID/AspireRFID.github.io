package pops.searcher.core;

import java.awt.Toolkit;

/**
 * Tickker thread.
 * @author rdagher
 *
 */
public class Ticker implements Runnable{
	PeriodSemaphore period = new PeriodSemaphore();
	boolean alive = true; // atomic

	public void run() {
		while(alive) {
			
			Toolkit.getDefaultToolkit().beep();
			try {
				Thread.sleep(period.getTimeout());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
	}	
}
