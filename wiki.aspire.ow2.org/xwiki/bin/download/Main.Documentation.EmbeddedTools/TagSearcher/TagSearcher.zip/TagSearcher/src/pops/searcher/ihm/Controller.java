package pops.searcher.ihm;

import pops.ale.codec.EpcCodec;
import pops.searcher.core.Reader;
import pops.searcher.core.Scanner;
import pops.searcher.readers.ReaderFactory;


/**
 * The controller object handles the core events incoming from the IHM.
 * @author rdagher
 *
 */
public class Controller implements ControlListener, Runnable {

	private Reader myReader;
	
	private Scanner myScanner;
	
	private PowerLevelListener powerListener;
	
	private byte [] tagId;
	
	private int[] powers;
	
	private long [] periods;
	
	private BinarySemaphore isRunning, isKilled;

	private boolean connected;
		
	/**
	 * 
	 * @param readerId
	 * @param powerListener
	 */
	public Controller(int readerId, PowerLevelListener powerListener) {
		this.myReader = ReaderFactory.getReader(readerId);
		this.powers = ReaderFactory.getPowers(readerId);
		this.periods = ReaderFactory.getPeriods(readerId);
		this.myScanner = new Scanner();
		this.powerListener = powerListener;
		this.isRunning = new BinarySemaphore();
		this.isKilled = new BinarySemaphore();
		this.connected = false;
	}

	public void setTag(String epcTagUri) {
		this.tagId = TagEncodingFactory.encodeTagId(epcTagUri, EpcCodec.MSB_FIRST);
		System.out.println("setTag : " + epcTagUri);
	}
	
	public void start() {
		// connect to reader if first call
		if (!connected) {
			// Connect Reader
			try {
				this.myReader.connect();
				connected = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		// reStart scanner
		this.myScanner.start();
		
		// restart controller
		System.out.println("Controller start : ");
		this.isRunning.signal(true);
	}
		
	public void stop() {
		// pause controller
		this.isRunning.signal(false);
		System.out.println("Controller stop : ");

		// pause scanner
		this.myScanner.pause();		
	}

	public void end() {
		// kill controller
		this.isKilled.signal(true);
		System.out.println("Controller end : ");

		// kill scanner
		this.myScanner.end();
		
		// Disconnect 
		if (connected) {
			try {
				this.myReader.disconnect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void run() {
		int powIdx = 0;
		
		// while not killed
		while (!isKilled.getFlag()) {
			// pause if demanded
			try {
				isRunning.lock(false); // while paused, wait
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			
			// Scan Cycle
			try {
				//System.out.println("Scanning");
				powIdx = myScanner.scan(myReader, powers, periods, tagId);
				this.powerListener.setPowerLevel(powIdx+1);
				// Thread.sleep(500); for simulation test
			} catch (Exception e) {
				// Log to window
				e.printStackTrace();
			}
		} // End While not killed
	}
}

/**
 * 
 * @author rdagher
 *
 */
class BinarySemaphore {
	private boolean flag = false;
	
	public synchronized void setFlag(boolean value) {
		flag = value;
	}
	
	public synchronized boolean getFlag() {
		return flag;	
	}
	
	/**
	 * Blocks until the signal method is called.
	 * @param condition boolean value.
	 * @throws InterruptedException
	 */
	public synchronized void lock(boolean condition) throws InterruptedException {
		while (flag == condition)
			this.wait();
	}
	
	/**
	 * Sets the semaphore flag, and notifies waiting threads.
	 * @param condition boolean value.
	 * @throws InterruptedException
	 */
	public synchronized void signal(boolean condition) {
		flag = condition;
		this.notifyAll();
	}
}