package pops.searcher.ihm;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;

import pops.searcher.readers.ReaderFactory;

public class Config {

	int readerId = -1;
	
	protected HashMap tagList = new HashMap();
	
	
	public static void readConfig (InputStream inStream, Config config) throws IOException {
		BufferedReader dis;
		String aLine, key, value ;
		int split;
		
		dis = new BufferedReader(new InputStreamReader(inStream));
		
		try {
			while ((aLine = dis.readLine()) != null) {
				// catch items
				if (aLine.startsWith("item=")) {
					split = aLine.indexOf(',');
					key = aLine.substring(aLine.indexOf('=')+1, split);
					value = aLine.substring(split+1).trim();
					config.tagList.put(key, value);
				} else if (aLine.startsWith("reader=")) {
					String readerName = aLine.substring(aLine.indexOf('=')+1).trim();
					if (readerName.equalsIgnoreCase("simu"))
						config.readerId = ReaderFactory.SIM_READER;
					else if (readerName.equalsIgnoreCase("caen"))
						config.readerId = ReaderFactory.CAEN_READER;
					else if (readerName.equalsIgnoreCase("intermec"))
						config.readerId = ReaderFactory.INTERMEC_READER;
					else
						config.readerId = -1;
				}
			}
			
		} finally {
			dis.close();
		}
	}
	
	public static void readConfig (String inputFile, Config config) throws IOException {
		readConfig(new FileInputStream(inputFile), config);
	}
	
	public static void readConfig (URL inputUrl, Config config) throws IOException {		
		readConfig(inputUrl.openConnection().getInputStream(), config);
	}	
	
}
