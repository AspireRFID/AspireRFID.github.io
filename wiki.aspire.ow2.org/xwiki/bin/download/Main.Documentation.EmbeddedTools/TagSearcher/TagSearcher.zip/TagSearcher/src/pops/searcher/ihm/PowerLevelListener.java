package pops.searcher.ihm;

public interface PowerLevelListener {
	
	/**
	 * 
	 */
	public final static int POWER_0 = 0 ;
	
	public final static int POWER_1 = 1;
	
	public final static int POWER_2 = 2;
	
	public final static int POWER_3 = 3;
	
	public final static int POWER_4 = 4;
	
	/**
	 * Notifies a listener of the observation of a tag at a given power.
	 * 
	 * @param obsPower the power at wich the tag was observed. If POWER_0, the tag was 
	 * not observed at all.
	 * 
	 * @see POWER_0
	 * @see POWER_1
	 * @see POWER_2
	 * @see POWER_3
	 * @see POWER_4
	 */
	public void setPowerLevel(int obsPower);
}
