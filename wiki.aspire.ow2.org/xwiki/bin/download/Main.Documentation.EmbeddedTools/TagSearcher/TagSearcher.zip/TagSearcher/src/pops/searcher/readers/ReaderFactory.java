package pops.searcher.readers;


import pops.searcher.core.Reader;

import com.caen.RFIDLibrary.CAENRFIDReader;
import com.intermec.datacollection.rfid.BasicBRIReader;

public class ReaderFactory {
	
	public final static int UNKNOWN_READER = -1;
	public final static int SIM_READER = 0;
	public final static int CAEN_READER = 1;
	public final static int INTERMEC_READER = 2;
	
	// TODO set powers and periods
	public final static int[] CAEN_POWERS = {25, 100, 200, 500};
	public final static int[] INTERMEC_POWERS = {25, 55, 85, 100};
	public final static long[] CAEN_PERIODS = {100,125,250,500};
	public final static long[] INTERMEC_PERIODS = {125,250,500,700};
	
	private static Reader caenReader = null;
	private static Reader intermecReader = null;
	private static Reader simuReader = null;


	public static Reader getReader(int readerId) {
		Reader theReader;
		
		switch(readerId) {
			// Simulator
			case SIM_READER :
				if (simuReader == null) {
					simuReader = new SimulatorWrapper();
				}
				theReader = simuReader;
				break;
			
			// CAEN
			case CAEN_READER :
				if (caenReader == null) {
					CAENRFIDReader myReader = new CAENRFIDReader();
					caenReader = new CaenReaderWrapper(myReader);
				}
				theReader = caenReader;
				break;
				
			// Intermec
			case INTERMEC_READER :
				if (intermecReader == null)
					intermecReader = new IntermecIP30BRIWrapper(new BasicBRIReader());
				theReader = intermecReader;
				break;
				
			// Invalid
			default :
				theReader = null;
		}
		
		return theReader;
	}


	public static int[] getPowers(int readerId) {
		int[] powers;
		
		switch(readerId) {
			// SIM
			case SIM_READER :
				powers = CAEN_POWERS;
				break;
			
			// CAEN
			case CAEN_READER :
				powers = CAEN_POWERS;
				break;
				
			// Intermec
			case INTERMEC_READER :
				powers = INTERMEC_POWERS;
				break;
				
			// Invalid
			default :
				powers = null;
		}
		
		return powers;
	}


	public static long[] getPeriods(int readerId) {
		long[] periods;
		
		switch(readerId) {
			// SIMU
			case SIM_READER :
				periods = CAEN_PERIODS;
				break;
			
				// CAEN
			case CAEN_READER :
				periods = CAEN_PERIODS;
				break;
				
			// Intermec
			case INTERMEC_READER :
				periods = INTERMEC_PERIODS;
				break;
				
			// Invalid
			default :
				periods = null;
		}
		
		return periods;
	}
}
