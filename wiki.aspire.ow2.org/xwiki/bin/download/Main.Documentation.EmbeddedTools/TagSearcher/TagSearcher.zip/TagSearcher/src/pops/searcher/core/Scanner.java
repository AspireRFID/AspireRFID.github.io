package pops.searcher.core;

/**
 * 
 * @author rdagher
 *
 */
public class Scanner {
	public final static long NOT_FOUND_PERIOD_MS = 1000;
	
	private Ticker aTikker;
	
	private Thread aTikkerThread;
	

	public synchronized void start() {
		aTikker = new Ticker();
		aTikker.period.setTimeout(NOT_FOUND_PERIOD_MS); // 1s beep
		aTikkerThread = new Thread(aTikker);
		aTikkerThread.start();
	}
	
	public synchronized void pause() {
		if (aTikker != null)
			aTikker.alive = false;
	}
	
	public synchronized void end() {
		if (aTikker != null)
			aTikker.alive = false;
	}
	
	/**
	 * 
	 * @param aReader
	 * @param powers example  50mw, 200mw, 500mw
	 * @param periods example 125ms, 250 ms, 500ms
	 * @param id
	 * @throws Exception 
	 */
	public synchronized int scan (Reader aReader, int[] powers, long[] periods, byte[] id) throws Exception {
		int idx = -1 ; // the index of the power level
		
		// for each power look for tag 
		for (int i = 0 ; i< powers.length; i++) {
			aReader.setPower(powers[i]);
			// if tag observed for first time
			if ((idx == -1) &&(aReader.hasTagInField(id))) {
				idx = i; // buffer power index
				System.out.println("Found @ power " + powers[i]);
				break; // Attention : added for intermec
			}
		}
		
		// if tag observed, tell tikker to beep at the given period
		if (idx != -1) {
			aTikker.period.setTimeout(periods[idx]);
		} else {
			aTikker.period.setTimeout(NOT_FOUND_PERIOD_MS);
		}
		
		return idx;
	}
}