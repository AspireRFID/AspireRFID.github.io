package pops.searcher.readers;

import gnu.javax.comm.wce.WCECommDriver;

import java.util.Arrays;

import pops.searcher.core.Reader;


import com.caen.RFIDLibrary.CAENRFIDLogicalSource;
import com.caen.RFIDLibrary.CAENRFIDPort;
import com.caen.RFIDLibrary.CAENRFIDProtocol;
import com.caen.RFIDLibrary.CAENRFIDReader;
import com.caen.RFIDLibrary.CAENRFIDTag;


/**
 * Caen Wrapper.
 * @author rdagher
 *
 */
public class CaenReaderWrapper implements Reader {
	private CAENRFIDReader myReader;
	private CAENRFIDLogicalSource mySource_0 ;

	private int timeout = 5;
	//private int retry = 5;
	
	
	/**
	 * Constructor
	 * @param myReader
	 */
	public CaenReaderWrapper(CAENRFIDReader myReader) {
		this.myReader = myReader;		
	}

	public boolean hasTagInField(byte[] tagId) throws Exception {
		boolean found = false;
		CAENRFIDTag[] myRFIDTags = null;
		
		  // for all cycles
	      for (int i = 0; (i < timeout) && (myRFIDTags == null) ; i++) {
	    	  myRFIDTags = mySource_0.InventoryTag();
	        //myRFIDTags = mySource_0.InventoryTag(tagId, (short)96/*bits*/, (short)0/* start index*/);
	      }
          
          /* Analyze received Tags */
          if (myRFIDTags != null) {
            for (int i = 0 ; (i < myRFIDTags.length) && (!found); i++) {
                byte[] id = myRFIDTags[i].GetId();
                
                if (Arrays.equals(id, tagId)) {
                     found = true;
                     //System.out.print("tag @source : " + myRFIDTags[i].GetSource().GetName() + "\n[" );
                
                    //for (int j = 0 ; j < id.length; j++)
                    //  System.out.print(TestCase.byteTohex(id[j]));
                }    		  
            }
          }
		return found;
	}

	public void setPower(int pw) throws Exception {
		this.myReader.SetPower(pw);
	}

	public void connect() throws Exception{
		System.loadLibrary("javaxcomm");
		// power up reader
        WCECommDriver.powerUpCaenReader();
        
        Thread.sleep(300);
        
        /* Connect to reader on COM1 */
        System.out.println("Connecting to reader : " + "RS232 : COM1");
        myReader.Connect(CAENRFIDPort.CAENRFID_RS232, "COM1:");
        System.out.println("Connection Success");
        
        /* configure Reader */
        // set protocol  : default is CAENRFID_EPC_C1G2
        myReader.SetProtocol(CAENRFIDProtocol.CAENRFID_EPC_C1G2);
        // set bitRate
        //System.out.println("Setting BitRate");
        //myReader.SetBitRate(CAENRFIDBitRate.TX10RX40);
        //myReader.SetBitRate(CAENRFIDBitRate.TX40RX40);
        //myReader.SetBitRate(CAENRFIDBitRate.TX40RX160);
        //System.out.println("SetBitRate OK");
        // set RF regulation
        //myReader.SetRFRegulation(CAENRFIDRFRegulations.ETSI_302208);
        
        
        // get and setup Logical Source 0
        mySource_0 = myReader.GetSources()[0];
        // set Q value
        //mySource_0.SetQ_EPC_C1G2(3);
        // set session 
        //mySource_0.SetSession_EPC_C1G2(CAENRFIDLogicalSourceConstants.EPC_C1G2_SESSION_S0);
        // set Power
//        myReader.SetPower(power);  // 500 mW
//        System.out.println("SetPower OK");
        
        // Tweak : Reset connection, otherwise won't work !!!
        myReader.Disconnect();
        myReader.Connect(CAENRFIDPort.CAENRFID_RS232, "COM1:");
	}

	public void disconnect() throws Exception{
		myReader.Disconnect();		
		WCECommDriver.powerDownCaenReader();
	}	
}
