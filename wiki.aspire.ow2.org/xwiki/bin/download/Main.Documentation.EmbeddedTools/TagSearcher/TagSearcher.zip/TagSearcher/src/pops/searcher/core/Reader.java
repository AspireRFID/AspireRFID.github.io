package pops.searcher.core;

/**
 * Reader abtraction for scanner.
 * @author rdagher
 *
 */
public interface Reader{
	public void connect() throws Exception;
	public void disconnect() throws Exception;
	public void setPower(int pw) throws Exception;	
	public boolean hasTagInField(byte[] tagId) throws Exception;
}