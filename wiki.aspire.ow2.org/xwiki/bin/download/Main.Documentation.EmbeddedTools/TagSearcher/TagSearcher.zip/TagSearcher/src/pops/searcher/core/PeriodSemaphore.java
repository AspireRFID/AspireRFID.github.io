package pops.searcher.core;

public class PeriodSemaphore {
	private long timeout = 0 ;

	/**
	 * Getter for timeout
	 * @return the timeout
	 */
	public synchronized long getTimeout() {
		return timeout;
	}

	/**
	 * Setter for timeout
	 * @param timeout the value to set
	 */
	public synchronized void setTimeout(long timeout) {
		this.timeout = timeout;
	}	
}