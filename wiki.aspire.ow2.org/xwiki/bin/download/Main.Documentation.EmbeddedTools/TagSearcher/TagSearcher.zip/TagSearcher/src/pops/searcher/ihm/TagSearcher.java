package pops.searcher.ihm;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.net.URL;
import java.util.HashMap;

import pops.ale.codec.EpcCodec;

public class TagSearcher extends Frame implements PowerLevelListener{

	/// Graphics
	private static final long serialVersionUID = 1L;
	private static final Color BLUE = new Color(0,0,255);  //  @jve:decl-index=0:
	private Panel panelSelectItem = null;
	private Panel panelPowerDisplay = null;
	private Panel panelControl = null;
	private Button buttonStart = null;
	private Button buttonStop = null;
	private Button Pow_0 = null;
	private Button Pow_1 = null;
	private Button Pow_2 = null;
	private Button Pow_3 = null;
	private Panel panelSelect = null;
	private Choice choiceItem = null;
	private Button buttonClose = null;
	private TextArea textArea = null;
	
	/// Functionnal
	private ControlListener aListener = null;
	private HashMap tagList;
	
	/**
	 * This is the default constructor
	 */
	public TagSearcher() {
		super();
		initialize();
	}
	
	public TagSearcher(ControlListener aListener, HashMap tagList) {
		this();
		this.tagList = tagList;
		// List of items
		Object[] items = tagList.keySet().toArray();
		for (int i = 0; i < items.length; i++)
			choiceItem.add(items[i].toString());
		
		// Select first item
		updateTextArea(textArea, items[0].toString(), tagList.get(items[0]).toString());
		
		if (aListener != null) 
			this.aListener = aListener;
		else {
			this.aListener = new ControlListener() {
				
				public void stop() {
					System.out.println("Stop Event fired !");					
				}
				
				public void start() {
					System.out.println("Start Event fired !");
				}
				
				public void end() {
					System.out.println("End Event fired !");					
				}

				public void setTag(String epcTagUri) {
					System.out.print("Code:\n\t");
					System.out.println(epcTagUri);
					System.out.print("\turn:epc:raw:x.");
					System.out.println(TagEncodingFactory.encodeStringTagId(epcTagUri, EpcCodec.MSB_FIRST));					
				}
			};
		}
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setLayout(new BorderLayout());
		this.setSize(320, 400);
		this.setResizable(false);
		this.setTitle("TagSearcher");

		this.add(getPanelSelectItem(), BorderLayout.CENTER);
		this.add(getPanelPowerDisplay(), BorderLayout.NORTH);
		this.add(getPanelControl(), BorderLayout.SOUTH);
	}

	public void setPowerLevel(int level) {
		switch (level) {
			case 0 :
				Pow_0.setBackground(null);
				Pow_1.setBackground(null);
				Pow_2.setBackground(null);
				Pow_3.setBackground(null);
				break;
			case 4 :
				Pow_0.setBackground(BLUE);
				Pow_1.setBackground(null);
				Pow_2.setBackground(null);
				Pow_3.setBackground(null);
				break;
			case  3:
				Pow_0.setBackground(BLUE);
				Pow_1.setBackground(BLUE);
				Pow_2.setBackground(null);
				Pow_3.setBackground(null);
				break;
			case 2 :
				Pow_0.setBackground(BLUE);
				Pow_1.setBackground(BLUE);
				Pow_2.setBackground(BLUE);
				Pow_3.setBackground(null);
				break;
			case 1 :
				Pow_0.setBackground(BLUE);
				Pow_1.setBackground(BLUE);
				Pow_2.setBackground(BLUE);
				Pow_3.setBackground(BLUE);
				break;
			default :
				// No action
				;
		}
	}
	/**
	 * This method initializes panelSelectItem	
	 * 	
	 * @return java.awt.Panel	
	 */
	private Panel getPanelSelectItem() {
		if (panelSelectItem == null) {
			panelSelectItem = new Panel();
			panelSelectItem.setLayout(new BorderLayout());
			panelSelectItem.add(getPanelSelect(), BorderLayout.CENTER);
		}
		return panelSelectItem;
	}

	/**
	 * This method initializes panelPowerDisplay	
	 * 	
	 * @return java.awt.Panel	
	 */
	private Panel getPanelPowerDisplay() {
		if (panelPowerDisplay == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(1);
			panelPowerDisplay = new Panel();
			panelPowerDisplay.setLayout(gridLayout);
			panelPowerDisplay.add(getPow_0(), null);
			panelPowerDisplay.add(getPow_1(), null);
			panelPowerDisplay.add(getPow_2(), null);
			panelPowerDisplay.add(getPow_3(), null);
		}
		return panelPowerDisplay;
	}

	/**
	 * This method initializes panelControl	
	 * 	
	 * @return java.awt.Panel	
	 */
	private Panel getPanelControl() {
		if (panelControl == null) {
			GridLayout gridLayout1 = new GridLayout();
			gridLayout1.setRows(1);
			panelControl = new Panel();
			panelControl.setLayout(gridLayout1);
			panelControl.add(getButtonStart(), null);
			panelControl.add(getButtonStop(), null);
			panelControl.add(getButtonClose(), null);
		}
		return panelControl;
	}

	/**
	 * This method initializes buttonStart	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getButtonStart() {
		if (buttonStart == null) {
			buttonStart = new Button();
			buttonStart.setLabel("Start");
			buttonStart.setBackground(Color.green);
			buttonStart.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					buttonStart.setEnabled(false);
					aListener.start();
					buttonStop.setEnabled(true);
					choiceItem.setEnabled(false);
				}
			});
		}
		return buttonStart;
	}

	/**
	 * This method initializes buttonStop	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getButtonStop() {
		if (buttonStop == null) {
			buttonStop = new Button();
			buttonStop.setLabel("Stop");
			buttonStop.setEnabled(false);
			buttonStop.setBackground(Color.orange);
			buttonStop.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					buttonStop.setEnabled(false);
					aListener.stop();
					buttonStart.setEnabled(true);
					choiceItem.setEnabled(true);
					setPowerLevel(0);
				}
			});
		}
		return buttonStop;
	}

	/**
	 * This method initializes Pow_0	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getPow_0() {
		if (Pow_0 == null) {
			Pow_0 = new Button();
			Pow_0.setEnabled(false);
			Pow_0.setName("Pow_0");
		}
		return Pow_0;
	}

	/**
	 * This method initializes Pow_1	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getPow_1() {
		if (Pow_1 == null) {
			Pow_1 = new Button();
			Pow_1.setEnabled(false);
			Pow_1.setName("Pow_1");
		}
		return Pow_1;
	}

	/**
	 * This method initializes Pow_2	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getPow_2() {
		if (Pow_2 == null) {
			Pow_2 = new Button();
			Pow_2.setEnabled(false);
			Pow_2.setName("Pow_2");
		}
		return Pow_2;
	}

	/**
	 * This method initializes Pow_3	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getPow_3() {
		if (Pow_3 == null) {
			Pow_3 = new Button();
			Pow_3.setEnabled(false);
			Pow_3.setName("Pow_3");
		}
		return Pow_3;
	}

	/**
	 * This method initializes panelSelect	
	 * 	
	 * @return java.awt.Panel	
	 */
	private Panel getPanelSelect() {
		if (panelSelect == null) {
			panelSelect = new Panel();
			panelSelect.setLayout(new BorderLayout());
			panelSelect.add(getChoiceItem(), BorderLayout.NORTH);
			panelSelect.add(getTextArea(), BorderLayout.CENTER);
		}
		return panelSelect;
	}

	/**
	 * This method initializes choiceItem	
	 * 	
	 * @return java.awt.Choice	
	 */
	private Choice getChoiceItem() {
		if (choiceItem == null) {
			choiceItem = new Choice();
			choiceItem.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					String item = e.getItem().toString();
					String tagUri = tagList.get(item).toString();
					
					updateTextArea(textArea, item, tagUri);
					aListener.setTag(tagUri);
				}
			});
		}
		return choiceItem;
	}

	private static void updateTextArea(TextArea textArea, String item, String tagUri) {
		textArea.setText("Selected item : "); // clear text area
		textArea.append(item);
		textArea.append("\nCode:\n  ");
		textArea.append(tagUri);
		textArea.append("\n  urn:epc:raw:x.");
		textArea.append(TagEncodingFactory.encodeStringTagId(tagUri, EpcCodec.MSB_FIRST));
		textArea.append("\n  GS1 :");
		textArea.append(TagEncodingFactory.getGS1(tagUri));
	}
	
	/**
	 * This method initializes buttonClose	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getButtonClose() {
		if (buttonClose == null) {
			buttonClose = new Button();
			buttonClose.setLabel("Close");
			buttonClose.setBackground(Color.red);
			buttonClose.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					exitApp();
				}
			});
		}
		return buttonClose;
	}

	public void exitApp() {
		System.out.println(" Closing");
		
		// finalize
		aListener.end();
		
		// dispose the frame
		dispose();
		
		// Exit
		System.out.println(" Close Ok");
		System.exit(0);
	}
	
	/**
	 * This method initializes textArea	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private TextArea getTextArea() {
		if (textArea == null) {
			textArea = new TextArea();
		}
		return textArea;
	}

	/**
	 * Command line call.
	 * @param args -u URL or absolute filename (ex. -u -u http://www.lifl.fr/~dagher/Config.txt)
	 * @throws Exception
	 */
	public static void main (String [] args) throws Exception {
		final TagSearcher demo;
		Controller myController;
		Config myConfig;
		
		// Parse configuration file
		myConfig = new Config();
		if (args[0].equals("-u"))
			Config.readConfig(new URL(args[1]), myConfig);
		else
			Config.readConfig(args[0], myConfig);
		
		// Init IHM
		demo = new TagSearcher(null, myConfig.tagList);
		demo.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				demo.exitApp();
			}
		});
		// Show		
		demo.setVisible(true);
		
		// Init Controller and bind it to the ihm
		myController = new Controller(myConfig.readerId, demo);
		demo.aListener = myController;
		myController.setTag((String) myConfig.tagList.get(demo.choiceItem.getSelectedItem()));
		
		// Run controller Loop
		myController.run();
		
		// Done
		System.out.println("Main Done");
	}
	
	
}  //  @jve:decl-index=0:visual-constraint="10,10"
