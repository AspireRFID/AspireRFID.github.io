package pops.searcher.ihm;

/**
 * This interface is useful for notifying a listener of control events upon the IHM.
 * 
 * @author rdagher
 *
 */
public interface ControlListener {
	/**
	 * Fires the start event. Starts or Restarts the execution.
	 */
	public void start(); 
	
	/**
	 * Fires a stop event. Pauses the execution.
	 */
	public void stop();
	
	/**
	 * Fire an end event to finalize and cleanup.
	 */
	public void end();
	
	/**
	 * Sets the tag to search
	 * @param epcTagUri the uri of the tag
	 */
	public void setTag(String epcTagUri);
}
