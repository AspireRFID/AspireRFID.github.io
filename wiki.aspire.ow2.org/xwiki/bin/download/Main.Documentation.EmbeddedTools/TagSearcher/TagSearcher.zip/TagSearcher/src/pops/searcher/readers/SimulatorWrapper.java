package pops.searcher.readers;

import pops.searcher.core.Reader;

public class SimulatorWrapper implements Reader {

	private int[] powers = ReaderFactory.CAEN_POWERS;
	private int currentPowerIndex;
	
	public void connect() throws Exception {
		System.out.println("Connected");
	}

	public void disconnect() throws Exception {
		System.out.println("Disconnected");
	}

	private boolean[] tab = {true,false,false,true}; 
	public boolean hasTagInField(byte[] tagId) throws Exception {
		System.err.println("i = " + currentPowerIndex);
		System.err.println("tab[i] = " + tab[currentPowerIndex]);
		return tab[currentPowerIndex];
	}

	public void setPower(int pw) throws Exception {
		System.out.println("\tSetting Power to " + pw);
		for (int i = 0; i< powers.length; i++) {
			if (powers[i] == pw) {
				currentPowerIndex = i;
				break;
			}
		}
	}

}
