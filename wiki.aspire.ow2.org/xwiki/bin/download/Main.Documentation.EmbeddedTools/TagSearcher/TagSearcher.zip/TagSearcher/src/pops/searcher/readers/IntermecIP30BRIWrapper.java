package pops.searcher.readers;

import pops.searcher.core.Reader;

import com.intermec.datacollection.rfid.BasicBRIReader;
import com.intermec.datacollection.rfid.BasicReaderException;

 /**
 * Intermec IP30 BRI Reader Wrapper.
 * @author rdagher
 *
 */
public class IntermecIP30BRIWrapper implements Reader {
	private BasicBRIReader myReader;
	private StringBuffer cmd ;
	private StringBuffer pwCmd ;
	
	/**
	 * Constructor
	 * @param myReader
	 */
	public IntermecIP30BRIWrapper(BasicBRIReader myReader) {
		this.myReader = myReader;
		// scan command
		this.cmd = new StringBuffer();
		cmd.append("RD WHERE HEX(1:4,12)=H");
		
		// set power command
		this.pwCmd = new StringBuffer();
		pwCmd.append("ATTRIBUTE FIELDSTRENGTH="); // numerical value
	}

	public boolean hasTagInField(byte[] tagId) {
		boolean found = false;
		String rsp = null;
		int abyte;
		
		// convert tag id to BRI syntax by appending it to scan command
		cmd.setLength(22);
		for(int i = 0 ; i<tagId.length; i++) {
			abyte = (tagId[i] & 0xFF);
			if (abyte < 16) cmd.append('0');
			cmd.append(Integer.toHexString(abyte));
		}
		//System.out.println("Sending cmd : " + cmd.toString());

		// scan tag
		try {
			rsp = this.myReader.execute(cmd.toString());
			// found if no timeout -> the response starts with H32...
			//System.out.println("RX: " + rsp);
			found = ((rsp!=null) && rsp.startsWith("H32"));
		} catch (BasicReaderException e) {
			found = false;
		}

		return found;
	}

	public void setPower(int db) throws Exception {
		pwCmd.setLength(24);
		pwCmd.append(db);
		//System.out.println("Sending pwCmd : " + pwCmd.toString());
		this.myReader.execute(pwCmd.toString());
	}

	public void connect() throws Exception {
		myReader.open(); // connect to default address
	}

	public void disconnect() throws Exception {
		myReader.close();		
	}	
}
