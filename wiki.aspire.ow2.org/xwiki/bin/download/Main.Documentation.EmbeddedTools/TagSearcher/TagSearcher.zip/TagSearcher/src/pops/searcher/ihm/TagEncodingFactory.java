package pops.searcher.ihm;

import java.util.StringTokenizer;

import pops.ale.codec.EncScheme;
import pops.ale.codec.EpcCodec;
import pops.ale.codec.Sgln96Codec;
import pops.ale.codec.Sgtin96Codec;

public class TagEncodingFactory {

	/**
	 * Decode tag Fields tokens.
	 */
	private final static Fields tagFields = new Fields();
	
	
	/**
	 * Encode a tag URI as an hex string from an epc-tag uri.
	 * @param tagUri
	 * @param endianness
	 * @return
	 */
	public static String encodeStringTagId(String tagUri, boolean endianness) {		
		// Convert to string
		return arrayToHexString(encodeTagId(tagUri, endianness));
	}
	
	private final static StringBuffer sBuffer = new StringBuffer();
	private static String arrayToHexString(byte[] id) {		
		sBuffer.setLength(0);
		for (int i = 0 ; i < id.length; i++) {
			int aByte = id[i]& 0xFF;
			if (aByte < 16)
				sBuffer.append('0');
			sBuffer.append(Integer.toHexString(aByte));
		}
		
		return sBuffer.toString().toUpperCase();
	}

	/**
	 * Encode a tag URI as byte array from an epc-tag uri.
	 * @param tagUri
	 * @param endianness
	 * @return
	 */
	public static byte[] encodeTagId(String tagUri, boolean endianness) {
		byte[] id  = null;
		
		int firstSeparator = tagUri.indexOf("tag") + 4;
		int lastSeparator = tagUri.lastIndexOf(":");
		String type = tagUri.substring(firstSeparator, lastSeparator);	
		
		// decode type
		if (!type.equals(EncScheme.SGTIN_96.toString()) && 
			!type.equals(EncScheme.SGLN_96.toString()))
			throw new IllegalArgumentException("unsupported type" + type);
		
		// get filter, company prefix, reference and serial		
		if (type.equals(EncScheme.SGTIN_96.toString())) {
			getFields(tagUri, lastSeparator, tagFields);
			id = Sgtin96Codec.buildTagData(endianness, Byte.parseByte(tagFields.filter), Long.parseLong(tagFields.cPrefix), 
					Integer.parseInt(tagFields.ref), Long.parseLong(tagFields.serial));
		}
		else if (type.equals(EncScheme.SGLN_96.toString())) {
			getFields(tagUri, lastSeparator, tagFields);
			id = Sgln96Codec.buildTagData(endianness, Byte.parseByte(tagFields.filter), Long.parseLong(tagFields.cPrefix), 
					Integer.parseInt(tagFields.ref), Long.parseLong(tagFields.serial));
		}else 
			throw new IllegalArgumentException("unsupported type" + type);
				
		return id;
	}
	
	private static void getFields(String tagUri, int lastSeparator, Fields tagFields) {
		StringTokenizer tokenizer = new StringTokenizer(tagUri.substring(lastSeparator+1),".");

		tagFields.filter = tokenizer.nextToken();
		tagFields.cPrefix = tokenizer.nextToken();
		tagFields.ref = tokenizer.nextToken();
		tagFields.serial = tokenizer.nextToken();
	}
	
	public static void main (String[] args) {
		
		System.out.println(TagEncodingFactory.encodeStringTagId("urn:epc:tag:sgln-96:1.211298.070875.43981", EpcCodec.MSB_FIRST));
	}

	private final static Sgtin96Codec sgtin96Codec  = new Sgtin96Codec();
	private final static Sgln96Codec sgln96Codec = new Sgln96Codec();
	
	public static String getGS1(String tagUri) {
		String gs1 = "";
		byte[] id = encodeTagId(tagUri, EpcCodec.MSB_LAST);
		
		switch(EpcCodec.decodeHeader(id)) {
			// sgtin-96
			case EpcCodec.SGTIN_96_HEADER :
				sgtin96Codec.decodeTagData(id);
				gs1 = Long.toString(sgtin96Codec.getGS1Number());
				break;
			
			// sgln-96
			case EpcCodec.SGLN_96_HEADER:
				sgln96Codec.decodeTagData(id);
				gs1 = Long.toString(sgln96Codec.getGS1Number());
				break;
		}
		
		return gs1;
	}
}

class Fields {
	String filter;
	String cPrefix;
	String ref;
	String serial;
}