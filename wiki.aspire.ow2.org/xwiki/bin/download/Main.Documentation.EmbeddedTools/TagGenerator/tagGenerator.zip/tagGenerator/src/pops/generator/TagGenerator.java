package pops.generator;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import pops.parser.Parser;

public class TagGenerator {
	
	/*
	 * Syntax :
	 */
	private static String printSyntax() {
		return "\t java TagGenerator.jar [<input file>] [<output file>]\n" 
		      +	"\t  the '-' argument stands for stdin or stdout.\n" +
		      	"Spec file example : \n" +
		      	"sgln-96:1.211298.070875.43981/10\n" +
		      	"sgln-96:1.211298.070875.[10000-10099]/1\n";			
	}
	
	/*
	 * Command Line interface.
	 */
	public static void main(String[] args) throws Exception{
		Parser aParser;
		InputStream input = System.in;
		OutputStream output = System.out;
		
		// open files if any
		if (args.length != 0) {
			if (args.length != 2) {
				System.err.println("Invalid syntax call.");
				System.err.println("Syntax : \n" + printSyntax());
				System.exit(-1);
			}
			// open input
			if (args[0].equals("-"))
				input = System.in;
			else
				input = new FileInputStream(args[0]);
			
			// open output
			if (args[1].equals("-"))
				output = System.out;
			else
				output = new FileOutputStream(args[1]);
			
		}
		try {
			// Parse input and generate output
			aParser = new Parser(input, output);		
			aParser.generatePatterns();
		} finally{
			// close streams
			output.close();		
			input.close();
		}

		System.out.println("done");
	}
}
